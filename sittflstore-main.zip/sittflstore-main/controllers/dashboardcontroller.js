
exports.getTopten=(req,res)=>{
    res.send("Top Ten flowers from database");

};